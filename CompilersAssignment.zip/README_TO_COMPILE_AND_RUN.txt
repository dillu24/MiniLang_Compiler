In order to compile and run REPL program:

1.Open CMD and go in the directory where this readme file is
2. run MiniLangCompilation.bat .. type "MiniLangICompilation"
3.Type "MiniLangI" in CMD

Note if some permissions are denied when compiling , compile again , it should work.
